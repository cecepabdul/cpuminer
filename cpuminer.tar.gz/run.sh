#!/bin/sh
while [ 1 ]; do

./cpuminer-sse2 -a yespowerr16 -o stratum+tcp://yenten-pool.info:63368 -u YiFp3rQQDuArqezp6bmsdDAP2e81TZcFHD
sleep 5

done
